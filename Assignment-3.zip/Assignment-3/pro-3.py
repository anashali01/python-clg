# Slice a string to print only the first five characters
str = "Hello World"
print(str[:5])