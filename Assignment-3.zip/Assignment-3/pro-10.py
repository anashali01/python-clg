#  Compare two numbers using comparison operators and print the results.

a = 10
b = 10
print(a == b)
print(a != b)
print(a > b)
print(a < b)
print(a >= b)
print(a <= b)