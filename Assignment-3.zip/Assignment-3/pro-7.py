# Convert a string to uppercase and lowercase.

str1 = "hello"
print(str1.upper())

str2 = "WORLD"
print(str2.lower())