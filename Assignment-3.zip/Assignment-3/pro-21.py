# Create a program that demonstrates the use of append(), pop(), and sort()
# methods in a list
list = ["alex" , "joe" , "sofi"]
list.append("John")
print(list)

list.pop()
print(list)

list.sort()
print(list)