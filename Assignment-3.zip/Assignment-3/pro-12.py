# Write a Python program to check if a number is positive, negative, or zero using if
# statements

number = 10  # You can change this value to test with different numbers

if number > 0:
    print(f"The number {number} is positive.")
elif number == 0:
    print(f"The number {number} is zero.")
else:
    print(f"The number {number} is negative.")