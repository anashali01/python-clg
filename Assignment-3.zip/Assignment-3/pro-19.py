# Print all even numbers from 1 to 50 using a for loop
for num in range(1, 51):
    if num % 2 == 0:
        print(num)