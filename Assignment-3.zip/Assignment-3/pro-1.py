# Declare a multiline string and print it.
str = """Hello This is 
multiline"""
print(str)