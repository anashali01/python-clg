# Concatenate two strings using both + and .join().

str1 = "Hello"
str2 = "World"
list = ["Alex" , "John" , "Deo"]
# print(str1 + str2)


ans = "-".join(list)
print(ans)