# Replace all occurrences of 'a' in a string with 'o'.
str = "ajax"
print(str.replace("a" , "o"))