# Write a program to demonstrate negative indexing in a string
str = "This is a message"
print(str[-7 : ])