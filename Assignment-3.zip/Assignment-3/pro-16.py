# Write a program that prints numbers from 1 to 10 using a while loop
i = 0
while i <= 10:
    print(i)
    i += 1