# Access and print the third character from a given string.
str = "Hello World"
print(str[3])