#  Create a program that checks if a given number is even or odd.
num = int(input("Enter Number:"))
if num%2==0:
    print("Even")
else:
    print("odd")