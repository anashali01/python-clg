# Write a program to reverse a list using a loop.
my_list = [1, 2, 3, 4, 5]
reversed_list = my_list[::-1]
print("Original list:", my_list)
print("Reversed list:", reversed_list)